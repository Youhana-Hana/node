function start() {
console.log("request Handler 'start' called");
}

function upload() {
console.log("request Handler 'upload' called");
}

expoerts.start = start;
exports.upload = upload;
